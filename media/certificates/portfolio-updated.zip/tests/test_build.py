from pathlib import Path
import tempfile,shutil,json,subprocess,threading,http.server,socketserver,functools,urllib.request,urllib.error
source=Path(__file__).resolve().parent.parent
with tempfile.TemporaryDirectory() as tmp:
 r=Path(tmp)/'repo';shutil.copytree(source,r,ignore=shutil.ignore_patterns('dist'))
 def build(): return subprocess.run(['python',str(r/'tools/build.py')],capture_output=True,text=True)
 res=build();assert res.returncode==0,res.stderr
 d=r/'dist'; home=(d/'index.html').read_text();assert '/projects/nims/' in home and '/skills/cisco/' in home and 'project.html?id=' not in home and 'skill.html?id=' not in home
 nim=(d/'projects/nims/index.html').read_text(); assert 'Planned' in nim and 'Isolation Forest' in nim and '(Verified)' not in nim
 assert not (d/'data/profile.json').exists();assert not list(d.rglob('*.yml'))
 print('PASS: generated homepage and 16 concrete direct detail files, planned features labelled, no raw profile/CMS files in output')
 class Handler(http.server.SimpleHTTPRequestHandler):
  def log_message(self,*a): pass
 handler=functools.partial(Handler,directory=str(d))
 with socketserver.TCPServer(('127.0.0.1',0),handler) as server:
  threading.Thread(target=server.serve_forever,daemon=True).start(); root=f'http://127.0.0.1:{server.server_address[1]}'
  for path in ['/','/projects/nims/','/skills/cisco/']:
   with urllib.request.urlopen(root+path) as response: assert response.status==200
  try:urllib.request.urlopen(root+'/projects/nonexistent/')
  except urllib.error.HTTPError as e: assert e.code==404
  else:raise AssertionError('unknown route')
  server.shutdown()
 print('PASS: local HTTP direct links and unknown URL 404 (GitHub Pages custom 404 not deployed/tested)')
 path=r/'data/projects/taskflow-pro.json'; task=json.loads(path.read_text()); task['status']='draft';task['cover']='/media/projects/secret.png';path.write_text(json.dumps(task))
 (r/'media/projects').mkdir(parents=True,exist_ok=True);(r/'media/projects/secret.png').write_bytes(b'private fake image')
 archived=r/'data/skills/docker.json';doc=json.loads(archived.read_text());doc['status']='archived';archived.write_text(json.dumps(doc))
 res=build();assert res.returncode==0,res.stderr
 assert not (d/'projects/taskflow-pro').exists() and not (d/'skills/docker').exists() and not (d/'media/projects/secret.png').exists()
 assert 'TaskFlow Pro' not in (d/'data/projects.json').read_text() and '/projects/taskflow-pro/' not in (d/'index.html').read_text()
 assert not any('TaskFlow Pro' in file.read_text(errors='ignore') for file in d.rglob('*') if file.is_file())
 print('PASS: draft and archived pages, JSON, homepage links, draft-only media excluded')
 task['status']='published';task['cover']='';task['skills']=['cisco'];path.write_text(json.dumps(task));res=build();assert res.returncode==0,res.stderr
 assert '/skills/cisco/' in (d/'projects/taskflow-pro/index.html').read_text()
 assert '/projects/taskflow-pro/' in (d/'skills/cisco/index.html').read_text()
 print('PASS: one CMS relationship appears on both published detail pages')
 task['skills']=['missing'];path.write_text(json.dumps(task));res=build();assert res.returncode!=0 and 'Unknown skill reference' in res.stderr
 print('PASS: broken relationship fails build')
 task['skills']=[];task['cover']='/media/projects/missing.png';path.write_text(json.dumps(task));res=build();assert res.returncode!=0
 print('PASS: missing referenced published image fails build')
 task['cover']='';path.write_text(json.dumps(task));profile=r/'data/profile.json';pr=json.loads(profile.read_text());pr['resume_pdf']='/media/cv/cv.pdf';pr['resume_verified']=True;profile.write_text(json.dumps(pr));(r/'media/cv').mkdir(exist_ok=True);(r/'media/cv/cv.pdf').write_bytes(b'');res=build();assert res.returncode!=0
 print('PASS: empty resume rejected')
 for file in (r/'data').rglob('*.json'):json.loads(file.read_text())
 print('PASS: all source content JSON parses')
