/* Shamikh Al-Aofiry portfolio: Stage 4, language behavior.
   Content management and detail pages are connected in a later stage.
   Navigation links remain native; the HTML has no theme control. */
(() => {
  'use strict';

  const STORAGE_KEY = 'portfolio-language';
  const DEFAULT_LANGUAGE = 'en';
  const translations = {
    en: {
      'navigation.openMenu': 'Menu',
      'navigation.closeMenu': 'Close menu',
      'navigation.skip': 'Skip to main content',
      'navigation.mainLabel': 'Main navigation',
      'navigation.footerLabel': 'Footer navigation',
      'navigation.languageLabel': 'Language',
      'navigation.language': 'Language',
      'navigation.about': 'About',
      'navigation.portfolio': 'Portfolio',
      'navigation.skills': 'Skills',
      'navigation.education': 'Education',
      'navigation.photography': 'Photography',
      'navigation.contact': 'Contact',
      'hero.title': 'Information Technology Student',
      'hero.subtitle': 'Networking & Infrastructure | AI & Automation',
      'hero.introduction': 'Exploring practical technology solutions, from network infrastructure to AI and automation.',
      'hero.portfolioAction': 'View Portfolio',
      'hero.contactAction': 'Contact',
      'about.heading': 'About',
      'about.biography': 'I am an Information Technology student interested in how reliable infrastructure and practical automation can help solve real problems. I am developing my skills through study and projects, with a particular interest in networks and AI-driven solutions.',
      'about.resume': 'Resume',
      'portfolio.heading': 'Portfolio',
      'portfolio.introduction': 'Selected projects exploring infrastructure, productivity, and design.',
      'portfolio.conceptCover': 'Conceptual cover placeholder',
      'portfolio.projectDetails': 'View project details',
      'portfolio.otherProjects': 'Other Projects on GitHub',
      'skills.heading': 'Skills',
      'education.heading': 'Education',
      'education.university': 'Thamar University',
      'education.college': 'College of Computer & Informatics',
      'education.degree': 'B.Sc. Information Technology',
      'education.expected': '(Expected)',
      'photography.heading': 'Photography',
      'photography.comingSoon': 'Coming Soon',
      'contact.heading': 'Contact',
      'contact.message': "I'm always open to freelance opportunities, interesting projects, and meaningful collaborations. Whether you have an idea to discuss or simply want to say hello, feel free to reach out. I'll do my best to respond to your email.",
      'contact.action': 'Get in Touch',
      'contact.socialLabel': 'Social links',
      'meta.title': 'Shamikh Al-Aofiry | Information Technology Student',
      'meta.description': 'Shamikh Al-Aofiry is an Information Technology student interested in networking, infrastructure, AI, and automation.',
      'brand.label': 'Shamikh Al-Aofiry, home'
    },
    ar: {
      'navigation.openMenu': 'القائمة',
      'navigation.closeMenu': 'إغلاق القائمة',
      'navigation.skip': 'انتقل إلى المحتوى الرئيسي',
      'navigation.mainLabel': 'التنقل الرئيسي',
      'navigation.footerLabel': 'التنقل في التذييل',
      'navigation.languageLabel': 'اللغة',
      'navigation.language': 'اللغة',
      'navigation.about': 'نبذة',
      'navigation.portfolio': 'المشاريع',
      'navigation.skills': 'المهارات',
      'navigation.education': 'التعليم',
      'navigation.photography': 'التصوير',
      'navigation.contact': 'التواصل',
      'hero.title': 'طالب تقنية معلومات',
      'hero.subtitle': 'الشبكات والبنية التحتية | الذكاء الاصطناعي والأتمتة',
      'hero.introduction': 'أستكشف حلولًا تقنية عملية، من البنية التحتية للشبكات إلى الذكاء الاصطناعي والأتمتة.',
      'hero.portfolioAction': 'استعرض المشاريع',
      'hero.contactAction': 'تواصل معي',
      'about.heading': 'نبذة',
      'about.biography': 'أنا طالب تقنية معلومات مهتم بدور البنية التحتية الموثوقة والأتمتة العملية في حل المشكلات. أعمل على تطوير مهاراتي من خلال الدراسة والمشاريع، مع اهتمام خاص بالشبكات والحلول المعتمدة على الذكاء الاصطناعي.',
      'about.resume': 'السيرة الذاتية',
      'portfolio.heading': 'المشاريع',
      'portfolio.introduction': 'مشاريع مختارة تستكشف البنية التحتية والإنتاجية والتصميم.',
      'portfolio.conceptCover': 'غلاف مفاهيمي مؤقت',
      'portfolio.projectDetails': 'عرض تفاصيل المشروع',
      'portfolio.otherProjects': 'مشاريع أخرى على GitHub',
      'skills.heading': 'المهارات',
      'education.heading': 'التعليم',
      'education.university': 'جامعة ذمار',
      'education.college': 'كلية الحاسوب والمعلوماتية',
      'education.degree': 'بكالوريوس تقنية المعلومات',
      'education.expected': '(متوقع)',
      'photography.heading': 'التصوير',
      'photography.comingSoon': 'قريبًا',
      'contact.heading': 'التواصل',
      'contact.message': 'يسعدني التواصل بشأن فرص العمل الحر والمشاريع المميزة والتعاون البنّاء. سواء كانت لديك فكرة لمناقشتها أو أردت إلقاء التحية، تواصل معي عبر البريد الإلكتروني وسأبذل جهدي للرد.',
      'contact.action': 'تواصل معي',
      'contact.socialLabel': 'روابط التواصل',
      'meta.title': 'Shamikh Al-Aofiry | طالب تقنية معلومات',
      'meta.description': 'Shamikh Al-Aofiry طالب تقنية معلومات مهتم بالشبكات والبنية التحتية والذكاء الاصطناعي والأتمتة.',
      'brand.label': 'Shamikh Al-Aofiry، الصفحة الرئيسية'
    }
  };

  function readLanguage() {
    try {
      const saved = window.localStorage.getItem(STORAGE_KEY);
      return saved === 'ar' || saved === 'en' ? saved : DEFAULT_LANGUAGE;
    } catch (_) {
      return DEFAULT_LANGUAGE;
    }
  }

  function saveLanguage(language) {
    try { window.localStorage.setItem(STORAGE_KEY, language); } catch (_) {
      // Language switching remains available for this page when storage is blocked.
    }
  }

  function applyLanguage(language) {
    const selected = Object.prototype.hasOwnProperty.call(translations, language) ? language : DEFAULT_LANGUAGE;
    const strings = translations[selected];
    document.documentElement.lang = selected;
    document.documentElement.dir = selected === 'ar' ? 'rtl' : 'ltr';

    document.querySelectorAll('[data-i18n]').forEach((element) => {
      const key = element.getAttribute('data-i18n');
      if (Object.prototype.hasOwnProperty.call(strings, key)) element.textContent = strings[key];
    });
    document.querySelectorAll('[data-i18n-aria-label]').forEach((element) => {
      const key = element.getAttribute('data-i18n-aria-label');
      if (Object.prototype.hasOwnProperty.call(strings, key)) element.setAttribute('aria-label', strings[key]);
    });
    document.querySelectorAll('[data-language]').forEach((button) => {
      button.setAttribute('aria-pressed', String(button.getAttribute('data-language') === selected));
    });
    document.querySelectorAll('[data-copy-en][data-copy-ar]').forEach((element) => {
      element.textContent = element.getAttribute(selected === 'ar' ? 'data-copy-ar' : 'data-copy-en');
    });
    document.querySelectorAll('[data-aria-en][data-aria-ar]').forEach((element) => {
      element.setAttribute('aria-label', element.getAttribute(selected === 'ar' ? 'data-aria-ar' : 'data-aria-en'));
    });
    document.querySelectorAll('[data-alt-en][data-alt-ar]').forEach((element) => {
      element.setAttribute('alt', element.getAttribute(selected === 'ar' ? 'data-alt-ar' : 'data-alt-en'));
    });
    document.title = document.body.getAttribute(selected === 'ar' ? 'data-page-title-ar' : 'data-page-title-en') || strings['meta.title'];
    const description = document.querySelector('meta[name="description"]');
    if (description && !document.body.hasAttribute('data-page-description-static')) description.setAttribute('content', strings['meta.description']);
    const brand = document.querySelector('.site-brand');
    if (brand) brand.setAttribute('aria-label', strings['brand.label']);
  }

  // Keep regular fragment links intact so native history, focus and URLs work.
  function initializeNavigation() {
    const navigation = document.querySelector('.site-header nav');
    if (!navigation) return;
    const links = Array.from(navigation.querySelectorAll('a[href^="#"]'));
    const targets = links.map((link) => {
      const id = link.getAttribute('href').slice(1);
      const section = id ? document.getElementById(id) : null;
      return section ? { link, section } : null;
    }).filter(Boolean);
    if (!targets.length) return;

    let scheduled = false;
    function updateCurrentSection() {
      scheduled = false;
      // Identify the last section to cross the reading line; none in the hero.
      const readingLine = Math.min(window.innerHeight * 0.3, 200);
      let current = null;
      targets.forEach((item) => {
        if (item.section.getBoundingClientRect().top <= readingLine) current = item.link;
      });
      links.forEach((link) => {
        if (link === current) link.setAttribute('aria-current', 'location');
        else link.removeAttribute('aria-current');
      });
    }
    function scheduleUpdate() {
      if (scheduled) return;
      scheduled = true;
      window.requestAnimationFrame(updateCurrentSection);
    }
    window.addEventListener('scroll', scheduleUpdate, { passive: true });
    window.addEventListener('resize', scheduleUpdate, { passive: true });
    window.addEventListener('hashchange', scheduleUpdate);
    updateCurrentSection();
  }

  // A plain, visible navigation remains available if JavaScript does not run.
  function initializeMobileMenu() {
    const button = document.querySelector('[data-menu-toggle]');
    const navigation = document.getElementById('main-navigation');
    if (!button || !navigation || typeof window.matchMedia !== 'function') return;
    const mobile = window.matchMedia('(max-width: 42rem)');
    let expanded = false;

    function render() {
      const isOpen = mobile.matches && expanded;
      button.hidden = !mobile.matches;
      button.setAttribute('aria-expanded', String(isOpen));
      button.setAttribute('data-i18n', isOpen ? 'navigation.closeMenu' : 'navigation.openMenu');
      const strings = translations[document.documentElement.lang] || translations.en;
      button.textContent = strings[isOpen ? 'navigation.closeMenu' : 'navigation.openMenu'];
      navigation.toggleAttribute('inert', mobile.matches && !isOpen);
      if (mobile.matches && !isOpen) navigation.setAttribute('data-menu-collapsed', 'true');
      else navigation.removeAttribute('data-menu-collapsed');
    }
    button.addEventListener('click', () => { expanded = !expanded; render(); });
    navigation.addEventListener('click', (event) => {
      if (mobile.matches && event.target.closest('a[href]')) {
        expanded = false;
        render();
      }
    });
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && mobile.matches && expanded) {
        expanded = false;
        render();
        button.focus();
      }
    });
    function handleBreakpoint() { expanded = false; render(); }
    if (typeof mobile.addEventListener === 'function') mobile.addEventListener('change', handleBreakpoint);
    else if (typeof mobile.addListener === 'function') mobile.addListener(handleBreakpoint);
    render();
  }

  // Native anchor scrolling retains browser history and fragment navigation.
  function initializeScrollPreference() {
    if (typeof window.matchMedia !== 'function') return;
    const preference = window.matchMedia('(prefers-reduced-motion: reduce)');
    function update() {
      document.documentElement.style.scrollBehavior = preference.matches ? 'auto' : 'smooth';
    }
    update();
    if (typeof preference.addEventListener === 'function') preference.addEventListener('change', update);
    else if (typeof preference.addListener === 'function') preference.addListener(update);
  }

  function initialize() {
    initializeNavigation();
    initializeScrollPreference();
    applyLanguage(readLanguage());
    initializeMobileMenu();
    document.querySelectorAll('button[data-language]').forEach((button) => {
      const language = button.getAttribute('data-language');
      if (language !== 'en' && language !== 'ar') return;
      button.addEventListener('click', () => {
        applyLanguage(language);
        saveLanguage(language);
      });
      button.disabled = false;
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initialize, { once: true });
  else initialize();
})();
