#!/usr/bin/env python3
"""Generate a static, published-only GitHub Pages artifact using Python's standard library."""
import html, json, re, shutil, sys
from pathlib import Path
from urllib.parse import urlparse
R=Path(__file__).resolve().parent.parent
OUT=R/'dist'
E=lambda value: html.escape(str(value or ''), quote=True)
def read(path):
    with open(path,encoding='utf8') as f: return json.load(f)
def bilingual(value, key='en'):
    return str(value.get(key,'') or '') if isinstance(value,dict) else ''
def text(en,ar,tag='span',cls=''):
    if not en and not ar: return ''
    en=en or ar; ar=ar or en
    return f'<{tag}' + (f' class="{E(cls)}"' if cls else '') + f' data-copy-en="{E(en)}" data-copy-ar="{E(ar)}">{E(en)}</{tag}>'
def localized(obj,tag='p'): return text(bilingual(obj),bilingual(obj,'ar'),tag)
def field(labelen,labelar,val):
    content=localized(val)
    return f'<section class="detail-section">{text(labelen,labelar,"h2")}{content}</section>' if content else ''
def valid_url(url,mail=False):
    if not url:return ''
    p=urlparse(str(url));return str(url) if p.scheme=='https' and p.netloc and not p.username and not p.password else ''
def external(url,labelen,labelar):
    url=valid_url(url)
    return f'<li><a href="{E(url)}" rel="noopener noreferrer">{text(labelen,labelar)}</a></li>' if url else ''
def media(value,exts=None):
    if not value:return ''
    rel=str(value).lstrip('/')
    if not rel.startswith('media/') or '\\' in rel or '..' in Path(rel).parts: raise ValueError('Unsafe media path: '+rel)
    path=(R/rel).resolve();root=(R/'media').resolve()
    if not path.is_relative_to(root) or not path.is_file() or path.is_symlink(): raise ValueError('Missing or unsafe media: '+rel)
    if exts and path.suffix.lower() not in exts:raise ValueError('Unsupported media format: '+rel)
    out=OUT/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,out)
    return '/'+rel
IMG={'.jpg','.jpeg','.png','.webp','.gif','.avif'}
DOC=IMG|{'.pdf'}
def records(folder):
    result=[];ids=set();slugs=set()
    for f in sorted((R/'data'/folder).glob('*.json')):
        obj=read(f); ident=obj.get('id','');slug=obj.get('slug','')
        if not re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*',ident) or not re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*',slug): raise ValueError(f'Invalid id or slug: {f.name}')
        if ident in ids or slug in slugs: raise ValueError('Duplicate id or slug: '+f.name)
        if obj.get('status') not in ('draft','published','archived'):raise ValueError('Invalid publication status: '+f.name)
        if not obj.get('name'):raise ValueError('Missing name: '+f.name)
        ids.add(ident);slugs.add(slug);result.append(obj)
    return sorted(result,key=lambda x:(float(x.get('order',0)),x['id']))
def name(item):return (item['name'],item.get('name_ar') or item['name'])
def details_url(kind,item):return '/'+kind+'/'+item['slug']+'/'
def image(path,alt):
    if not path:return ''
    uri=media(path,IMG); en=bilingual(alt) or 'Project image';ar=bilingual(alt,'ar') or en
    return f'<figure class="detail-media"><img src="{E(uri)}" alt="{E(en)}" data-alt-en="{E(en)}" data-alt-ar="{E(ar)}" loading="lazy" decoding="async"></figure>'
def evidence(items):
    entries=[]
    for i in items or []:
        label=i.get('label') or {};en=bilingual(label) or 'Evidence';ar=bilingual(label,'ar') or en
        url=media(i.get('file'),DOC) if i.get('file') else valid_url(i.get('url'))
        if url: entries.append(f'<li><a href="{E(url)}">{text(en,ar)}</a></li>')
    return f'<section class="detail-section">{text("Supporting evidence","الأدلة الداعمة","h2")}<ul>{"".join(entries)}</ul></section>' if entries else ''
def feature_list(items,title_en,title_ar):
    entries=[]
    statuses={'planned':('Planned','مخطط'),'implemented':('Implemented','منفّذ'),'verified':('Verified','تم التحقق')}
    for entry in items or []:
        status=entry.get('status'); content=localized(entry.get('text'),'span')
        if status not in statuses:raise ValueError('Feature or technology requires an explicit valid status')
        if content: entries.append('<li>'+content+' <strong>('+text(*statuses[status])+')</strong></li>')
    return f'<section class="detail-section">{text(title_en,title_ar,"h2")}<ul>{"".join(entries)}</ul></section>' if entries else ''
def page(template,item,body,profile):
    en,ar=name(item); title=en+' | '+profile['name']; ar_title=ar+' | '+(profile.get('name_ar') or profile['name'])
    values={'TITLE':title,'META':bilingual(item.get('summary')) or bilingual(item.get('description')) or en,'TITLE_EN':title,'TITLE_AR':ar_title,'NAME_EN':profile['name'],'NAME_AR':profile.get('name_ar') or profile['name']}
    for k,v in values.items():template=template.replace('{{'+k+'}}',E(v))
    return template.replace('{{BODY}}',body)
def bi_attrs(obj):
    en=bilingual(obj); ar=bilingual(obj,'ar') or en
    return f' data-copy-en="{E(en)}" data-copy-ar="{E(ar)}"'
def replace_i18n(source,key,obj):
    en=bilingual(obj);ar=bilingual(obj,'ar') or en
    if not en:return source
    pat=r'(<(?:p|h1|h2|h3|span)[^>]*data-i18n="'+re.escape(key)+r'"[^>]*)(>)(.*?)(</(?:p|h1|h2|h3|span)>)'
    return re.sub(pat,lambda m:m.group(1)+bi_attrs(obj)+m.group(2)+E(en)+m.group(4),source,flags=re.S)
def do_build():
    if OUT.exists():shutil.rmtree(OUT)
    OUT.mkdir(); (OUT/'data').mkdir()
    for f in ('style.css','script.js'):shutil.copyfile(R/f,OUT/f)
    profile=read(R/'data/profile.json');education=read(R/'data/education.json');certs=read(R/'data/certificates.json')
    projects_all=records('projects');skills_all=records('skills'); allskills={s['id']:s for s in skills_all}
    for p in projects_all:
        for ref in p.get('skills') or []:
            if ref not in allskills:raise ValueError('Unknown skill reference: '+str(ref))
    projects=[x for x in projects_all if x['status']=='published'];skills=[x for x in skills_all if x['status']=='published'];skillmap={s['id']:s for s in skills}
    for kind,data in [('projects',projects),('skills',skills)]:
        # Clean output includes only published records and published relationships.
        safe=[]
        for item in data:
            c=dict(item)
            if kind=='projects':
                c['skills']=[v for v in c.get('skills',[]) if v in skillmap]
                if c.get('live_verified') is not True: c['live_url']=''
            safe.append(c)
        (OUT/'data'/f'{kind}.json').write_text(json.dumps(safe,ensure_ascii=False,indent=2)+'\n')
    template=(R/'index.html').read_text()
    page_title=profile.get('name','')+' | '+bilingual(profile.get('title'))
    ar_title=(profile.get('name_ar') or profile.get('name',''))+' | '+(bilingual(profile.get('title'),'ar') or bilingual(profile.get('title')))
    template=re.sub(r'<title>.*?</title>',lambda m:'<title>'+E(page_title)+'</title>',template,count=1,flags=re.S)
    template=template.replace('<body>',f'<body data-page-description-static data-page-title-en="{E(page_title)}" data-page-title-ar="{E(ar_title)}">',1)
    template=re.sub(r'<meta name="description" content="[^"]*">',lambda m:'<meta name="description" content="'+E(bilingual(profile.get('introduction')))+'">',template,count=1)
    # Updated content is generated into the public HTML, never loaded from CMS at runtime.
    for key,obj in [('hero.title',profile.get('title')),('hero.subtitle',profile.get('subtitle')),('hero.introduction',profile.get('introduction')),('about.biography',profile.get('biography')),('contact.message',profile.get('contact_message')),('education.university',education.get('university')),('education.college',education.get('college')),('education.degree',education.get('degree'))]:
        template=replace_i18n(template,key,obj)
    display=profile.get('name',''); arname=profile.get('name_ar') or display
    for class_name in ('site-brand',):
        template=re.sub(r'(<a class="'+class_name+r'"[^>]*)(>)(.*?)(</a>)',lambda m:m.group(1)+f' data-copy-en="{E(display)}" data-copy-ar="{E(arname)}"'+m.group(2)+E(display)+m.group(4),template,count=1,flags=re.S)
    template=re.sub(r'(<h1 id="hero-title")([^>]*>).*?(</h1>)',lambda m:m.group(1)+f' data-copy-en="{E(display)}" data-copy-ar="{E(arname)}"'+m.group(2)+E(display)+m.group(3),template,flags=re.S)
    template=template.replace('2026 Shamikh Al-Aofiry','2026 '+E(display))
    email=str(profile.get('email',''))
    if not re.fullmatch(r'[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+',email):raise ValueError('Invalid public email')
    template=template.replace('alofiry1@gmail.com',E(email))
    linkedin=valid_url(profile.get('linkedin')); telegram=valid_url(profile.get('telegram')); github=valid_url(profile.get('github'))
    if linkedin:template=template.replace('https://www.linkedin.com/in/shamkh-alafiry-780172391',E(linkedin))
    else:template=re.sub(r'<li><a href="https://www.linkedin.com/in/shamkh-alafiry-780172391" rel="me">LinkedIn</a></li>','',template)
    if github:
        template=template.replace('<li hidden data-github-profile-item><a data-github-profile-link>GitHub</a></li>',f'<li><a href="{E(github)}" rel="me">GitHub</a></li>')
        template=template.replace('<a class="other-projects-link" data-github-profile-link data-i18n="portfolio.otherProjects" hidden>',f'<a class="other-projects-link" href="{E(github)}" data-i18n="portfolio.otherProjects">')
    if telegram:template=template.replace('</ul>\n    </section>\n  </main>',f'<li><a href="{E(telegram)}" rel="me">Telegram</a></li></ul>\n    </section>\n  </main>')
    profile_img=profile.get('profile_image')
    if profile_img:
        uri=media(profile_img,IMG);template=template.replace('<div class="hero__monogram" aria-hidden="true">SA</div>',f'<img class="hero__monogram" src="{E(uri)}" alt="{E(display)}" width="384" height="384">')
    resume=profile.get('resume_pdf')
    if resume and profile.get('resume_verified') is True:
        # This is a sanity check, not a substitute for human review or a full PDF validator.
        resume_rel=str(resume).lstrip('/')
        if not resume_rel.startswith('media/') or '\\' in resume_rel or '..' in Path(resume_rel).parts: raise ValueError('Unsafe resume path')
        fp=(R/resume_rel).resolve()
        if not fp.is_relative_to((R/'media').resolve()): raise ValueError('Unsafe resume path')
        data=fp.read_bytes()
        if fp.suffix.lower()!='.pdf' or len(data)<128 or not data.startswith(b'%PDF-') or b'%%EOF' not in data[-2048:]:raise ValueError('Resume PDF failed basic integrity checks')
        url=media(resume,{'.pdf'})
        template=template.replace('<a class="resume-link" data-resume-link data-i18n="about.resume" hidden>',f'<a class="resume-link" data-resume-link data-i18n="about.resume" href="{E(url)}">')
    years=f'<p><span>{E(education.get("start_year"))}</span> <span aria-hidden="true">&ndash;</span> <span>{E(education.get("expected_year"))}</span> <span data-i18n="education.expected">(Expected)</span></p>'
    template=re.sub(r'<p><span>2023</span>.*?</p>',lambda m:years,template,count=1,flags=re.S)
    description=localized(education.get('description'))
    template=template.replace('</article>\n    </section>\n\n    <section id="contact"',description+'</article>\n    </section>\n\n    <section id="contact"',1)
    cards=[]
    for p in projects:
        if not p.get('featured'):continue
        en,ar=name(p); cover=p.get('cover'); suffix={'nims':'nims','taskflow-pro':'taskflow','smart-design-pro':'smart-design'}.get(p['id'],'')
        visual=f'<img src="{E(media(cover,IMG))}" alt="{E(en)}" loading="lazy" decoding="async">' if cover else f'<div aria-hidden="true">{E(en)}</div>{text("Conceptual cover placeholder","غلاف مفاهيمي مؤقت","figcaption")}'
        details_en='View project details: '+en; details_ar='عرض تفاصيل المشروع: '+ar
        cards.append(f'<article class="project-card"><figure class="project-card__cover project-card__cover--{suffix}">{visual}</figure><div class="project-card__content">{text(en,ar,"h3")}{localized(p.get("full_name"))}{localized(p.get("summary"))}<a href="{E(details_url("projects",p))}" aria-label="{E(details_en)}" data-aria-en="{E(details_en)}" data-aria-ar="{E(details_ar)}">{text("View project details","عرض تفاصيل المشروع")}</a></div></article>')
    start=template.index('      <div class="project-list" data-project-list>');end=template.index('      <a class="other-projects-link"',start)
    template=template[:start]+'      <div class="project-list" data-project-list>'+''.join(cards)+'</div>\n'+template[end:]
    items=''.join('<li><a href="'+E(details_url('skills',s))+'">'+text(*name(s))+'</a></li>' for s in skills)
    template=re.sub(r'<ul class="skill-list" data-skill-list>.*?</ul>',lambda m:'<ul class="skill-list" data-skill-list>'+items+'</ul>',template,count=1,flags=re.S)
    certlist=[]
    for c in certs:
        if c.get('status')!='published':continue
        label=c.get('name','');url=media(c.get('file'),DOC) if c.get('file') else ''
        certificate=f'<a href="{E(url)}">{text(label,c.get("name_ar") or label)}</a>' if url else text(label,c.get('name_ar') or label)
        verification=external(c.get('verification_url'),'Verify certificate','التحقق من الشهادة')
        certlist.append('<li>'+certificate+' '+E(c.get('issuer',''))+' '+E(c.get('issue_date',''))+localized(c.get('description'))+('<ul>'+verification+'</ul>' if verification else '')+'</li>')
    if certlist:template=template.replace('</article>\n    </section>\n\n    <section id="contact"','</article>'+text('Certificates','الشهادات','h3')+'<ul>'+''.join(certlist)+'</ul>\n    </section>\n\n    <section id="contact"',1)
    (OUT/'index.html').write_text(template)
    pt=(R/'projects/index.html').read_text();st=(R/'skills/index.html').read_text()
    for p in projects:
        title=name(p);body='<header class="detail-hero">'+text(*title,'h1')+localized(p.get('full_name'))+localized(p.get('summary'))+'</header>'
        if p.get('cover'):body+=image(p['cover'],{'en':title[0],'ar':title[1]})
        for key,en,ar in [('overview','Overview','نظرة عامة'),('problem','Problem','المشكلة'),('objectives','Objectives','الأهداف'),('role','Role','الدور')]:body+=field(en,ar,p.get(key))
        body+=feature_list(p.get('features'),'Features','المزايا')+feature_list(p.get('technologies'),'Technologies','التقنيات')
        for img in p.get('images') or []:body+=image(img,{'en':title[0],'ar':title[1]})
        body+=evidence(p.get('evidence'))
        links=external(p.get('live_url') if p.get('live_verified') is True else '', 'Live demo','العرض المباشر')+external(p.get('github_url'),'GitHub repository','مستودع GitHub')+external(p.get('video_url'),'Video','فيديو')
        if links:body+='<section class="detail-section">'+text('Links','الروابط','h2')+'<ul>'+links+'</ul></section>'
        related=[skillmap[x] for x in p.get('skills',[]) if x in skillmap]
        if related:body+='<section class="detail-section">'+text('Related skills','المهارات المرتبطة','h2')+'<ul>'+''.join('<li><a href="'+details_url('skills',s)+'">'+text(*name(s))+'</a></li>' for s in related)+'</ul></section>'
        out=OUT/'projects'/p['slug'];out.mkdir(parents=True);(out/'index.html').write_text(page(pt,p,body,profile))
    for s in skills:
        body='<header class="detail-hero">'+text(*name(s),'h1')+'</header>'+field('Description','الوصف',s.get('description'))+field('Practical experience','الخبرة العملية',s.get('experience'))+evidence(s.get('evidence'))
        related=[p for p in projects if s['id'] in (p.get('skills') or [])]
        if related:body+='<section class="detail-section">'+text('Related projects','المشاريع المرتبطة','h2')+'<ul>'+''.join('<li><a href="'+details_url('projects',p)+'">'+text(*name(p))+'</a></li>' for p in related)+'</ul></section>'
        out=OUT/'skills'/s['slug'];out.mkdir(parents=True);(out/'index.html').write_text(page(st,s,body,profile))
    (OUT/'404.html').write_text('<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Page not found</title><link rel="stylesheet" href="/style.css"></head><body><main class="detail-shell"><section class="detail-hero"><h1>Page not found</h1><p>We could not find this page.</p><p lang="ar" dir="rtl">تعذر العثور على هذه الصفحة.</p><a href="/">Home / الرئيسية</a></section></main></body></html>')
    print(f'Built {len(projects)} published projects and {len(skills)} published skills to dist/.')
if __name__=='__main__':
    try: do_build()
    except (OSError,ValueError,TypeError,KeyError,json.JSONDecodeError) as exc: print('Build failed:',exc,file=sys.stderr);sys.exit(1)
